//This class is copied from MultiFormatReader, except we limit it to a small set of readers
//to keep it light and fast. For now, we don't need to support things like datamatrix or pdf417

#include <zxing/ZXing.h>
#include <CBBarcodeReader.h>
#include <zxing/qrcode/QRCodeReader.h>
#include <zxing/oned/MultiFormatOneDReader.h>
#include <zxing/ReaderException.h>

using zxing::Ref;
using zxing::Result;
using zxing::CBBarcodeReader;

// VC++
using zxing::DecodeHints;
using zxing::BinaryBitmap;

CBBarcodeReader::CBBarcodeReader() {}

Ref<Result> CBBarcodeReader::decode(Ref<BinaryBitmap> image) {
  setHints(DecodeHints::DEFAULT_HINT);
  return decodeInternal(image);
}

Ref<Result> CBBarcodeReader::decode(Ref<BinaryBitmap> image, DecodeHints hints) {
  setHints(hints);
  return decodeInternal(image);
}

Ref<Result> CBBarcodeReader::decodeWithState(Ref<BinaryBitmap> image) {
  // Make sure to set up the default state so we don't crash
  if (readers_.size() == 0) {
    setHints(DecodeHints::DEFAULT_HINT);
  }
  return decodeInternal(image);
}

void CBBarcodeReader::setHints(DecodeHints hints) {
  hints_ = hints;
  readers_.clear();
  bool tryHarder = hints.getTryHarder();

  bool addOneDReader = hints.containsFormat(BarcodeFormat::UPC_E) ||
    hints.containsFormat(BarcodeFormat::UPC_A) ||
    hints.containsFormat(BarcodeFormat::UPC_E) ||
    hints.containsFormat(BarcodeFormat::EAN_13) ||
    hints.containsFormat(BarcodeFormat::EAN_8) ||
    hints.containsFormat(BarcodeFormat::CODABAR) ||
    hints.containsFormat(BarcodeFormat::CODE_39) ||
    hints.containsFormat(BarcodeFormat::CODE_93) ||
    hints.containsFormat(BarcodeFormat::CODE_128) ||
    hints.containsFormat(BarcodeFormat::ITF) ||
    hints.containsFormat(BarcodeFormat::RSS_14) ||
    hints.containsFormat(BarcodeFormat::RSS_EXPANDED);
  if (addOneDReader && !tryHarder) {
    readers_.push_back(Ref<Reader>(new zxing::oned::MultiFormatOneDReader(hints)));
  }
  if (hints.containsFormat(BarcodeFormat::QR_CODE)) {
    readers_.push_back(Ref<Reader>(new zxing::qrcode::QRCodeReader()));
  }
  if (addOneDReader && tryHarder) {
    readers_.push_back(Ref<Reader>(new zxing::oned::MultiFormatOneDReader(hints)));
  }
  if (readers_.size() == 0) {
    readers_.push_back(Ref<Reader>(new zxing::qrcode::QRCodeReader()));
	readers_.push_back(Ref<Reader>(new zxing::oned::MultiFormatOneDReader(hints)));
  }
}

Ref<Result> CBBarcodeReader::decodeInternal(Ref<BinaryBitmap> image) {
  for (unsigned int i = 0; i < readers_.size(); i++) {
    try {
      return readers_[i]->decode(image, hints_);
    } catch (ReaderException const& re) {
      (void)re;
      // continue
    }
  }
  throw ReaderException("No code detected");
}

CBBarcodeReader::~CBBarcodeReader() {}
