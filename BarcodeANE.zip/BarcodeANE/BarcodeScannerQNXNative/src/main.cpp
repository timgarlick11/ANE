/*
 * Copyright (c) 2011 Research In Motion Limited.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
#include "FlashRuntimeExtensions.h"
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include "CBBarcodeReader.h"
#include <zxing/Exception.h>
#include <zxing/common/GreyscaleLuminanceSource.h>
#include <zxing/common/HybridBinarizer.h>
#include <zxing/DecodeHints.h>
#include <zxing/BarcodeFormat.h>

using namespace std;
using namespace zxing;

extern "C" {
	void BarcodeExtInitializer(void** extDataToSet,
			FREContextInitializer* ctxInitializerToSet,
			FREContextFinalizer* ctxFinalizerToSet);
	void BarcodeExtFinalizer();

	void ContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx,
			uint32_t* numFunctionsToSet, const FRENamedFunction** functionsToSet);
	void ContextFinalizer(FREContext ctx);

	FREObject scan(FREContext ctx, void* functionData, uint32_t argc,
			FREObject argv[]);
}

struct arg_struct {
	FREContext * ctx;
	Ref<BinaryBitmap> * img;
};


void * decodeCore(void * arguments) {
	struct arg_struct *args = (struct arg_struct *)arguments;

	DecodeHints hints(DecodeHints::QR_CODE_HINT);
	hints.addFormat(BarcodeFormat::EAN_8);
	hints.addFormat(BarcodeFormat::EAN_13);
	hints.addFormat(BarcodeFormat::UPC_A);
	hints.addFormat(BarcodeFormat::UPC_E);
	hints.addFormat(BarcodeFormat::CODE_39);
	hints.addFormat(BarcodeFormat::CODE_93);
	hints.addFormat(BarcodeFormat::CODE_128);

	CBBarcodeReader reader;

	try {
		Ref<Result> result(reader.decode(*(args->img), hints));
		const char *out = result->getText()->getText().c_str();
		FREDispatchStatusEventAsync(*(args->ctx), (const uint8_t *)"SCANNED", (const uint8_t *)out);
	} catch (Exception &e) {
		//No result found
	}

	delete args->ctx;
	delete args->img;
	delete args;

	return NULL;
}

FREObject decode(FREContext ctx, void* functionData, uint32_t argc, FREObject argv[]) {
	FREBitmapData bitmapData;
	FREAcquireBitmapData(argv[0], &bitmapData);

	int width = bitmapData.width;
	int height = bitmapData.height;
	int isPremultiplied = bitmapData.isPremultiplied;
	int stride = bitmapData.lineStride32;

	uint32_t * input = bitmapData.bits32;

	int area = width * height;
	ArrayRef<char> data(area);
	for(int i = 0; i < area; i++) {
		uint32_t rgb = input[i];
		data[i] = (((rgb >> 16) & 0xff) * 0.2126) + (((rgb >> 8) & 0xff) * 0.7152) + ((rgb & 0xff) * 0.0722);
	}
	Ref<LuminanceSource> source(new GreyscaleLuminanceSource(data, stride, height, 0, 0, width, height));

	// Turn it into a binary image.
	Ref<Binarizer> binarizer(new HybridBinarizer(source));
	Ref<BinaryBitmap> * image = new Ref<BinaryBitmap>(new BinaryBitmap(binarizer));

	FREReleaseBitmapData(argv[0]);

	struct arg_struct * args = (arg_struct *) malloc(sizeof(arg_struct));
	args->ctx = new FREContext(ctx);
	args->img = image;

	pthread_t thread;
	pthread_create (&thread, NULL, decodeCore, (void *) args);

	return NULL;
}

/**
 * The runtime calls this method once when it loads an ActionScript extension.
 * Implement this function to do any initializations that your extension requires.
 * Then set the output parameters.
 *
 * @param extDataToSet
 *             A pointer to a pointer to the extension data of the ActionScript extension.
 *             Create a data structure to hold extension-specific data. For example, allocate
 *             the data from the heap, or provide global data. Set extDataToSet to a pointer
 *             to the allocated data.
 * @param ctxInitializerToSet
 *             A pointer to the pointer to the FREContextInitializer() function. Set
 *             ctxInitializerToSet to the FREContextInitializer() function you defined.
 * @param ctxFinalizerToSet
 *             A pointer to the pointer to the FREContextFinalizer() function. Set
 *             ctxFinalizerToSet to the FREContextFinalizer() function you defined. You can
 *             set this pointer to NULL.
 */
void BarcodeExtInitializer(void** extDataToSet,
		FREContextInitializer* ctxInitializerToSet,
		FREContextFinalizer* ctxFinalizerToSet) {
	*extDataToSet = NULL;
	*ctxInitializerToSet = &ContextInitializer;
	*ctxFinalizerToSet = &ContextFinalizer;
}

/**
 * The runtime calls this function when it disposes of the ExtensionContext instance
 * for this extension context.
 */
void BarcodeExtFinalizer() {
}

/**
 * The runtime calls this method when the ActionScript side calls ExtensionContext.createExtensionContext().
 *
 * @param extData
 *             A pointer to the extension data of the ActionScript extension.
 * @param ctxType
 *             A string identifying the type of the context. You define this string as
 *             required by your extension. The context type can indicate any agreed-to meaning
 *             between the ActionScript side and native side of the extension. If your extension
 *             has no use for context types, this value can be Null. This value is a UTF-8
 *             encoded string, terminated with the null character.
 * @param ctx
 *             An FREContext variable. The runtime creates this value and passes it to FREContextInitializer().
 * @param numFunctionsToSet
 *             A pointer to a unint32_t. Set numFunctionsToSet to a unint32_t variable containing
 *             the number of functions in the functionsToSet parameter.
 * @param functionsToSet
 *             A pointer to an array of FRNamedFunction elements. Each element contains a pointer
 *             to a native function, and the string the ActionScript side uses in the ExtensionContext
 *             instance's call() method.
 */
void ContextInitializer(void* extData, const uint8_t* ctxType, FREContext ctx,
		uint32_t* numFunctionsToSet, const FRENamedFunction** functionsToSet) {

		*numFunctionsToSet = 1;

		FRENamedFunction* func = (FRENamedFunction*) malloc(sizeof(FRENamedFunction) * 1);
		func[0].name = (const uint8_t*) "decode";
		func[0].functionData = NULL;
	    func[0].function = &decode;

		*functionsToSet = func;
}

/**
 * The runtime calls this function when it disposes of the ExtensionContext instance for this extension context.
 *
 * @param ctx
 *             The FREContext variable that represents this extension context.
 */
void ContextFinalizer(FREContext ctx) {
}
