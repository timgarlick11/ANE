#ifndef CBBARCODEREADER_H_
#define CBBARCODEREADER_H_

#include <zxing/Reader.h>
#include <zxing/common/BitArray.h>
#include <zxing/Result.h>
#include <zxing/DecodeHints.h>

namespace zxing {
  class CBBarcodeReader : public Reader {
  private:
    Ref<Result> decodeInternal(Ref<BinaryBitmap> image);

    std::vector<Ref<Reader> > readers_;
    DecodeHints hints_;

  public:
    CBBarcodeReader();

    Ref<Result> decode(Ref<BinaryBitmap> image);
    Ref<Result> decode(Ref<BinaryBitmap> image, DecodeHints hints);
    Ref<Result> decodeWithState(Ref<BinaryBitmap> image);
    void setHints(DecodeHints hints);
    ~CBBarcodeReader();
  };
}



#endif /* CBBARCODEREADER_H_ */
