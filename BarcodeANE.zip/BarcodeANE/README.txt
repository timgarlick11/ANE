Author: Colin Childs
Copyright (c) 2013 CleanBrain Software, Inc.


This is the barcode scanner Native extension I wrote for iOS, Android, and Blackberry devices. It is a complex beast, but at the time of writing,
it was the only possible solution to work cross platform. I have included this simple set of instructions in case you happen to be unfortunate enough to have to make some changes to this ANE.


LIBRARIES USED
--------------------------------------------------------------------------------------------------------------------------------------------
For the Android project, I am sending an Intent to the ZXing official barcode scanner. It should do all the work for you and send back a result. See the project on their website for additional parameters you can pass in to customize it more.

For iOS, I went with the ZBar library. It is the only one at the time of this writing that does not cost thousands of dollars in licensing fees. It is not the best, but it still works pretty darn well. They have documentation and forums for reference if needed.

Blackberry uses a ZXing port to C++. The library was ported by RIM for BB 10 devices, but it works great on the Playbook as well. The iOS and Android solutions both come with built in native views that do all the work for you. The Blackberry library only decodes barcodes, so we do all the display stuff on our end in ActionScript then send the BitmapData to the C++ to be processed.



FILE STRUCTURE
--------------------------------------------------------------------------------------------------------------------------------------------
1) BarcodeScannerAS - The ActionScript interface between our app and the native code
2) BarcodeScannerAndroidJava - The Java project that contains all the native Java code.
3) BarcodeScannerIOSNative - The XCode project containing all the native Objective C code.
4) BarcodeScannerQNXNative - The Blackberry Native C++ project.
5) build - Where all the magic happens




A NOTE ABOUT CHANGING ANYTHING
--------------------------------------------------------------------------------------------------------------------------------------------
Ok, so you have to fix a bug or something. What do you do? If you need to alter the ActionScript library, open it using Flash Builder and make any necessary changes, then rebuild the library. A fresh, new .swc should now be in the bin folder for the project. Copy the swc from the bin folder to the build folder. Right click and extract the contents of the swc into that folder. It should produce a library.swf and some useless xml file. Take the library.swf and paste it into each of the sub folders (ios, android, blackberry, default).

Now lets say you did something more drastic and need to change something in the Android project. You will need all of the Android development tools. After installing them into Eclipse, open up the project. If all worked well, it should now build without any errors. Make the necessary changes, and do a build. Now right click on the project and export it as a jar. Navigate to build/android and select androidBarcodeScanner.jar. When it prompts you, overwrite the old one.

The iOS library is an even more complex beast. For this, you will have to use a Mac. Transfer the iOS project folder to it somehow (Network drive or USB drive or something). Open the XCode project file using XCode. Click on the project name at the top of the project structure on the left. Make sure any paths in the settings are set according to where you placed the project. Note that there are two sets of settings, one for the project, one for the library. Not sure what the difference is... just change them both. Make any necessary changes and build (CMD + B). In the navigation, expand "Products" and you should see a .a library file in there. Right click and open it in Finder. Be sure to transfer not only your changes to the project, but also that library file, back to your other machine. Place the newly created .a file in build/ios.

Making changes to the Blackberry project requires you to have the Blackberry Native tools, or NDK. At the time of writing, there are two: 2.1 and 10.2. The 2.1 NDK is primarily for Playbook native development. 10.2 is for Blackberry 10 devices such as the Z10. I THINK you can use either, but to be sure it would be compatible with both, I used the older, 2.1 NDK. Simply import the project and make any necessary changes. Be sure to build a Device-Release version. You can do this by either setting the active target to Device-Release and rebuilding or by right-clicking on the project and going to Build Configurations -> Build Selected then choosing Device-Release. You should now have a folder in the project called Device-Release with a shared library libBarcodeScanner-arm.so. Copy this binary to build/qnx. If for some reason, you need to modify the ZXing library or see the source, I got it from https://github.com/blackberry/zxing. It took me a while to build this project because the directions in the README are a bit unclear. To build this library from source, open the command prompt and navigate to your BB NDK folder. It should have a batch file called something like "bbndk-env.bat". Run this script to set up this session with the correct environment variables. With the same command prompt window, navigate to the downloaded ZXing source. Go to zpp/core and run "make". The resulting library files can be found in arm (for device) and x86 (for the simulator). Copy arm/so-le-v7/libzxingS.a to BarcodeScannerQNXNative/lib/device and x86/so/libzxingS.a to BarcodeScannerQNXNative/lib/sim.

To make the ANE, simply run build.bat or navigate to the build folder using the command prompt and run the provided build command. This step is necessary for any changes you make, no matter how minor. Copy the generated ane into your mobile lib folder. Be sure to refresh the project and do a clean build to ensure the changes are recognized. This ANE build step requires you to use AIR 3.5. Currently, any version above that does not allow you to create an ANE for the Playbook. Be sure to have adt in your path (should be [FlashBuilderFolder]/sdks/[Your3.5SDK]/bin).