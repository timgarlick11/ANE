//
//  CTZBarReaderViewController.h
//  ZBarScanner
//
//  Created by cleanbrain on 9/27/13.
//  Copyright (c) 2013 __MyCompanyName__. All rights reserved.
//

//Please note that we only use our own subclass of the reader view controller
//to fix a memory leak in the library. You may need to use theirs with future library versions.

#ifndef ZBarScanner_CTZBarReaderViewController_h
#define ZBarScanner_CTZBarReaderViewController_h

#import <Foundation/Foundation.h>
#import "ZBarReaderViewController.h"

@interface CTZBarReaderViewController : ZBarReaderViewController
@end

#endif
