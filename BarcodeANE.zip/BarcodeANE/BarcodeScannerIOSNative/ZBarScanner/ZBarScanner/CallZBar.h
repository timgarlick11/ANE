//
//  CallZBar.h
//  QRZBar
//
//  Created by JAN HEUFF on 15/02/2012.
//  Copyright (c) 2012 RANCON. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FlashRuntimeExtensions.h"
#import <UIKit/UIKit.h>

@interface CallZBar : NSObject < ZBarReaderDelegate >

-(void) scan:(FREContext *)ctx;
-(void) cleanUp;

@end
