//
//  CallZBar.m
//  QRZBar
//
//  Created by JAN HEUFF on 15/02/2012.
//  Copyright (c) 2012 RANCON. All rights reserved.
//

#import "CallZBar.h"
#import "CTZBarReaderViewController.h"

@implementation CallZBar

FREContext *context;
//Please note that we only use our own subclass of the reader view controller
//to fix a memory leak in the library. You may need to use theirs with future library versions.
CTZBarReaderViewController *myReader;

- (void) scan:(FREContext *)ctx
{
    context = ctx;
    NSLog(@"Build 0.0.0.9");
    NSLog(@"JAMES RANCON Scan");
    // ADD: present a barcode reader that scans from the camera feed
    myReader = [CTZBarReaderViewController new];
    
    //Make a full screen custom overlay
    CGRect bounds = [[UIScreen mainScreen] bounds];
    UIView *overlay = [[UIView alloc] initWithFrame:bounds];
	overlay.backgroundColor = [UIColor clearColor];
    myReader.wantsFullScreenLayout = YES;
    [overlay sizeToFit];
    
    
    //Create a toolbar with a cancel button and add it to the overlay
	UIToolbar *toolbar = [[UIToolbar alloc]
                          initWithFrame:CGRectMake(0.0,0.0,MAX(bounds.size.width, bounds.size.height),44.0)];
	UIBarButtonItem *cancelButton = [[UIBarButtonItem alloc]
                                     initWithBarButtonSystemItem:UIBarButtonSystemItemCancel
                                     target:self
                                     action:@selector(cleanUp)];
	toolbar.items = [NSArray arrayWithObjects:cancelButton,nil];
	[overlay addSubview:toolbar];
	[cancelButton release];
	[toolbar release];
	
    //Set some optional values on the reader
	myReader.cameraOverlayView = overlay;
	myReader.showsZBarControls = NO;
    myReader.tracksSymbols = NO;
    myReader.cameraFlashMode = UIImagePickerControllerCameraFlashModeOff;
    
    myReader.readerDelegate = self;
    myReader.supportedOrientationsMask = ZBarOrientationMaskAll;
    
    ZBarImageScanner *scanner = myReader.scanner;
    
    //disable rarely used I2/5 to improve performance
    [scanner setSymbology: ZBAR_I25
                   config: ZBAR_CFG_ENABLE
                       to: 0];
    
    id delegate = [[UIApplication sharedApplication] delegate];
    [[[delegate window] rootViewController] presentModalViewController:myReader animated:NO];
}

- (void) imagePickerController: (UIImagePickerController*) reader
 didFinishPickingMediaWithInfo: (NSDictionary*) info
{
    NSLog(@"JAMES RANCON Callback function");
    // ADD: get the decode results
    id<NSFastEnumeration> results =
    [info objectForKey: ZBarReaderControllerResults];
    ZBarSymbol *symbol = nil;
    for(symbol in results)
        break;
    
    NSString *event_name = @"SCANNED";
    FREDispatchStatusEventAsync(context, (uint8_t*)[event_name UTF8String], (uint8_t*)[[symbol data] UTF8String]);
     
    [self cleanUp];
}

- (void) cleanUp {
    [myReader dismissModalViewControllerAnimated: YES];
    context = nil;
    [myReader release];
}


@end
