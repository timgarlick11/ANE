//Please note that we only use our own subclass of the reader view controller
//to fix a memory leak in the library. You may need to use theirs with future library versions.

#import "CTZBarReaderViewController.h"

@implementation CTZBarReaderViewController 
- (void) loadView
{
    self.view = [[[UIView alloc] initWithFrame: CGRectMake(0, 0, 320, 480)] autorelease];
}
@end