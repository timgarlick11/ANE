package com.cleanbrain.barcode;

import android.content.Context;
import android.content.Intent;
import android.util.Log;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

public class ScanBarcodeFunction implements FREFunction{

	public FREObject call(FREContext freContext, FREObject[] args) {

		try {
			Context context = freContext.getActivity().getApplicationContext();
			Intent intent = new Intent(context, ZXingActivity.class);
			intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
			context.startActivity(intent);
		} catch (Exception e) {
			Log.i("ScanBarcodeFunction", e.getMessage());
		}
		
		return null;
	}

}
