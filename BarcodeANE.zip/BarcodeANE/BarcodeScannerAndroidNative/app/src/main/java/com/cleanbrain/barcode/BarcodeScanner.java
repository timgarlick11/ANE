package com.cleanbrain.barcode;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREExtension;

public class BarcodeScanner implements FREExtension{

	public static FREContext extensionContext;
	
	public FREContext createContext(String arg0) {
		return new BarcodeScannerContext();
	}

	public void dispose() {
		extensionContext = null;
	}

	public void initialize() {
		
	}
	
	public static void notifyBarcodeScanned(String result) {
		extensionContext.dispatchStatusEventAsync(result, "barcodeScanned");
	}

}
