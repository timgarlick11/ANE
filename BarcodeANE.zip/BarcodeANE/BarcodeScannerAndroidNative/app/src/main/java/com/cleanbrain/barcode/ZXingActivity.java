package com.cleanbrain.barcode;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class ZXingActivity extends Activity {
	public static final int REQUEST_CODE = 0x0000c0de;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		IntentIntegrator integrator = new IntentIntegrator(this);
		integrator.addExtra("RESULT_DISPLAY_DURATION_MS", 0L);
		integrator.addExtra("PROMPT_MESSAGE", "");
		integrator.initiateScan();
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		super.onActivityResult(requestCode, resultCode, data);
		
		if (resultCode == RESULT_OK) {
			IntentResult scanResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
			BarcodeScanner.notifyBarcodeScanned(scanResult.getContents());
		} else if (resultCode == RESULT_CANCELED) {
			BarcodeScanner.notifyBarcodeScanned("");
		}

		this.finish();
	}
}
