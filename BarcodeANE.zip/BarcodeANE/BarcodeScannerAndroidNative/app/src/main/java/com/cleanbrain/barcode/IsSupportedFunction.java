package com.cleanbrain.barcode;

import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.util.Log;

import com.adobe.fre.FREContext;
import com.adobe.fre.FREFunction;
import com.adobe.fre.FREObject;

public class IsSupportedFunction implements FREFunction {

	private static final String BS_PACKAGE = "com.google.zxing.client.android";
	private static final String BSPLUS_PACKAGE = "com.srowen.bs.android";
	
	public static final Collection<String> TARGET_ALL_KNOWN = list(
			BS_PACKAGE,			// Barcode Scanner
			BSPLUS_PACKAGE, // Barcode Scanner+
			BSPLUS_PACKAGE + ".simple" // Barcode Scanner+ Simple
			// What else supports this intent?
	);
	
	//Default dialog values
	private static String TITLE = "Install Barcode Scanner?";
	private static String MESSAGE = "The Barcode Scanner application is required. Would you like to install it now?";
	private static String YES = "Yes";
	private static String NO = "No";
	
	public FREObject call(FREContext context, FREObject[] args) {
		try {
			
			TITLE = args[0].getAsString();
			MESSAGE = args[1].getAsString();
			YES = args[2].getAsString();
			NO = args[3].getAsString();
			
			Intent intentScan = new Intent(BS_PACKAGE + ".SCAN");
			String targetAppPackage = findTargetAppPackage(intentScan);
			if (targetAppPackage == null) {
				showDownloadDialog();
				return FREObject.newObject(false);
			}
			
			return FREObject.newObject(true); 
		} catch (Exception e) {
		}
		return null;
	}
	
	private String findTargetAppPackage(Intent intent) {
		PackageManager pm = BarcodeScanner.extensionContext.getActivity().getPackageManager();
		List<ResolveInfo> availableApps = pm.queryIntentActivities(intent, PackageManager.MATCH_DEFAULT_ONLY);
		if (availableApps != null) {
			for (ResolveInfo availableApp : availableApps) {
				String packageName = availableApp.activityInfo.packageName;
				if (TARGET_ALL_KNOWN.contains(packageName)) {
					return packageName;
				}
			}
		}
		return null;
	} 
	
	private AlertDialog showDownloadDialog() {
		AlertDialog.Builder downloadDialog = new AlertDialog.Builder(BarcodeScanner.extensionContext.getActivity());
		downloadDialog.setTitle(TITLE);
		downloadDialog.setMessage(MESSAGE);
		downloadDialog.setPositiveButton(YES, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialogInterface, int i) {
				Uri uri = Uri.parse("market://details?id=" + BS_PACKAGE);
				Intent intent = new Intent(Intent.ACTION_VIEW, uri);
				try {
					BarcodeScanner.extensionContext.getActivity().startActivity(intent);
					} catch (ActivityNotFoundException anfe) {
						// Hmm, market is not installed
						Log.w("init", "Android Market is not installed; cannot install Barcode Scanner");
					}
				}
			});
		downloadDialog.setNegativeButton(NO, new DialogInterface.OnClickListener() {
			public void onClick(DialogInterface dialogInterface, int i) {}
		});
		return downloadDialog.show();
	}
	
	private static Collection<String> list(String... values) {
		return Collections.unmodifiableCollection(Arrays.asList(values));
	} 

}
